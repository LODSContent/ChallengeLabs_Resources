import requests

def translate_text(text, languages):
    api_key = "your-api-key"  # Replace with your Azure Translator API key
    region = "eastus"  # Replace with your Azure region
    endpoint = "https://api.cognitive.microsofttranslator.com"  # Correct endpoint
    path = f"/translate?api-version=3.0&to={'&to='.join(languages)}"
    url = endpoint + path  # Fixed URL concatenation

    headers = {
        "Ocp-Apim-Subscription-Key": api_key,
        "Ocp-Apim-Subscription-Region": region,
        "Content-Type": "application/json"
    }

    body = [{"text": text}]

    try:
        response = requests.post(url, headers=headers, json=body)
        response.raise_for_status()  # Raise an exception for HTTP errors

        translations = response.json()

        # Extract translations properly
        translated_texts = {
            t["to"]: t["text"] for t in translations[0]["translations"]
        }
        return translated_texts  # Return a dictionary of language -> translation

    except requests.exceptions.RequestException as e:
        return {"error": "Request failed", "message": str(e)}

if __name__ == "__main__":
    languages = ["fr", "de", "it", "zh-Hans"]  # French, German, Italian, Simplified Chinese
    translation = translate_text("Good morning, how are you?", languages)

    if "error" in translation:
        print(f"Error: {translation['error']} - {translation['message']}")
    else:
        for lang, translated_text in translation.items():
            print(f"{lang}: {translated_text}")
