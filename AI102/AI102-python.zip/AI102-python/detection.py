import requests

def detect_and_translate(text):
    api_key = "YOUR-API-KEY-HERE"  # Replace with your Azure API Key
    region = "eastus"  # Replace with your Azure region
    endpoint = "https://api.cognitive.microsofttranslator.com"  # Correct Azure endpoint

    headers = {
        "Ocp-Apim-Subscription-Key": api_key,
        "Ocp-Apim-Subscription-Region": region,
        "Content-Type": "application/json"
    }
    
    body = [{"text": text}]

    try:
        # Step 1: Detect language
        detect_url = f"{endpoint}/detect?api-version=3.0"
        detect_response = requests.post(detect_url, headers=headers, json=body)
        detect_response.raise_for_status()

        detected_language = detect_response.json()[0]['language']
        print(f"Detected Language: {detected_language}")

        # Step 2: Translate detected language to English (if not already English)
        if detected_language == "en":
            print("The text is already in English.")
            return text  # Return the original text

        translate_url = f"{endpoint}/translate?api-version=3.0&to=en"
        translate_response = requests.post(translate_url, headers=headers, json=body)
        translate_response.raise_for_status()

        translation = translate_response.json()
        translated_text = translation[0]["translations"][0]["text"]
        print(f"Translated Text: {translated_text}")

        return translated_text  # Return the translated text

    except requests.exceptions.RequestException as e:
        print(f"Error: {str(e)}")
        return None

if __name__ == "__main__":
    detect_and_translate("Bonjour tout le monde")  # Example input
