import requests
import json

subscription_key = "your-api-key"
endpoint = "your-endpoint/"
location = "YOUR_REGION"

import requests
import json

subscription_key = "your-api-key"
endpoint = "your-endpoint/"  # No trailing slash
location = "YOUR_REGION"

path = "/translate?api-version=3.0"
languages = "&to=es&to=fr"

constructed_url = endpoint + path + languages  # Results in full valid URL

headers = {
    "Ocp-Apim-Subscription-Key": subscription_key,
    "Ocp-Apim-Subscription-Region": location,
    "Content-type": "application/json"
}

body = [{ "text": "Hello, world!" }]

response = requests.post(constructed_url, headers=headers, json=body)

try:
    result = response.json()
    print(json.dumps(result, indent=4, ensure_ascii=False))
except Exception as e:
    print("Error:", response.text)
