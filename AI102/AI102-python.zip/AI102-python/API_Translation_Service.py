import requests

def translate_text(text, to_language):
    api_key = "your-api-key"  # Replace with your Azure Translator API key
    region = "eastus"  # Replace with your Azure region
    endpoint = "https://api.cognitive.microsofttranslator.com"  # Correct Azure endpoint
    path = f"/translate?api-version=3.0&to={to_language}"
    url = endpoint + path  # Fixed concatenation issue

    headers = {
        "Ocp-Apim-Subscription-Key": api_key,
        "Ocp-Apim-Subscription-Region": region,
        "Content-Type": "application/json"
    }

    body = [{"text": text}]

    try:
        response = requests.post(url, headers=headers, json=body)
        response.raise_for_status()  # Raise an exception for HTTP errors

        translations = response.json()
        return translations  # Returns the full response JSON

    except requests.exceptions.RequestException as e:
        return {"error": "Request failed", "message": str(e)}

if __name__ == "__main__":
    translation = translate_text("Hello, Team Hexelo!", "es")
    if "error" in translation:
        print(f"Error: {translation['error']} - {translation['message']}")
    else:
        print(f"Translation: {translation[0]['translations'][0]['text']}")
