import requests

def detect_and_translate_file(file_path):
    api_key = "YOUR-API-KEY-HERE"  # Replace with your Azure Translator API key
    region = "eastus"  # Replace with your Azure region
    endpoint = "https://api.cognitive.microsofttranslator.com"  # Correct endpoint

    headers = {
        "Ocp-Apim-Subscription-Key": api_key,
        "Ocp-Apim-Subscription-Region": region,
        "Content-Type": "application/json"
    }

    try:
        # Read lines from file
        with open(file_path, "r", encoding="utf-8") as file:
            lines = file.readlines()

        # Validate and prepare the request body
        body = [{"text": line.strip()} for line in lines if line.strip()]
        if not body:
            print("Error: The input file is empty or contains only whitespace.")
            return

        # Step 1: Detect Language
        detect_url = f"{endpoint}/detect?api-version=3.0"
        detect_response = requests.post(detect_url, headers=headers, json=body)
        detect_response.raise_for_status()  # Ensure no HTTP error

        detected_languages = [result["language"] for result in detect_response.json()]
        
        # Step 2: Translate if necessary
        translate_body = [
            {"text": text["text"]} for text, lang in zip(body, detected_languages) if lang != "en"
        ]

        if not translate_body:
            print("All text is already in English.")
            return

        translate_url = f"{endpoint}/translate?api-version=3.0&to=en"
        translate_response = requests.post(translate_url, headers=headers, json=translate_body)
        translate_response.raise_for_status()  # Ensure no HTTP error

        translations = translate_response.json()

        # Step 3: Print results
        for original, detected_lang, translation in zip(lines, detected_languages, translations):
            translated_text = translation["translations"][0]["text"]
            print(f"[{detected_lang}] Original: {original.strip()} | Translated: {translated_text}")

    except requests.exceptions.RequestException as e:
        print(f"Error: {str(e)}")
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")

if __name__ == "__main__":
    detect_and_translate_file("input_texts.txt")
