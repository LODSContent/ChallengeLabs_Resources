﻿ # Connect to Azure AD interactively
Connect-AzureAD | Out-Null

# Connect to Microsoft Graph (for Intune operations)
Connect-MgGraph -Scopes "DeviceManagementManagedDevices.ReadWrite.All","DeviceManagementServiceConfig.ReadWrite.All", "DeviceManagementConfiguration.ReadWrite.All" -ContextScope CurrentUser -NoWelcome | out-null

# Retrieve all devices in AzureAD
$azureADDevices = Get-AzureADDevice  

# Retrieve all devices in Intune
$intuneDevices = Get-MgbetaDeviceManagementManagedDevice

# Check if there are any devices in Intune and if so, remove.
if ($intuneDevices.Count -eq 0) {
    Write-Output "No devices found in Intune."
} else {
    # Delete all devices in Intune
    foreach ($device in $intuneDevices) {
       Remove-MgbetaDeviceManagementManagedDevice -ManagedDeviceId $device.Id
       Write-Output "Deleted Intune device: $($device.DeviceName)"
    }
}  

# Check if there are any devices in Azure AD and if so, remove.
if ($azureADDevices.Count -eq 0) {
    Write-Output "No devices found in Azure AD."
} else {
    # Delete all devices in Azure AD
    foreach ($device in $azureADDevices) {
        Remove-AzureADDevice -ObjectId $device.ObjectId
        Write-Output "Deleted Azure AD device: $($device.DisplayName)"
    }
} 

# Define the group name
$groupName = "Lab Test"

# Get the group if it exists
$group = Get-AzureADGroup -SearchString $groupName | Where-Object { $_.DisplayName -eq $groupName }

if ($group)
{
    # Remove the group
    Remove-AzureADGroup -ObjectId $group.ObjectId -Force
}

# Define the Graph API base URL for Intune
$graphApiBaseUrl = "https://graph.microsoft.com/v1.0/deviceManagement"

# Function to delete resources by their type and name
function Delete-IntuneResources {
    param (
        [string]$resourceType
    )

    # Get the resources of the specified type
    $resources = Invoke-RestMethod -Uri "$graphApiBaseUrl/$resourceType" -Method Get -Headers $headers

    foreach ($resource in $resources.value) {
        # Delete each resource
        $resourceId = $resource.id
        Invoke-RestMethod -Uri "$graphApiBaseUrl/$resourceType/$resourceId" -Method Delete -Headers $headers
    }
}

# Assume $headers contains the authorization header
$headers = @{
    Authorization = "Bearer $accessToken"
}

# Delete deployment profiles
$deploymentProfiles = Get-MgBetaDeviceManagementWindowsAutopilotDeploymentProfile
If(!$deploymentProfiles){Write-output "No deployment profiles found."} Else{ 
foreach ($profile in $deploymentProfiles) {
    Remove-MgBetaDeviceManagementWindowsAutopilotDeploymentProfile -DeploymentProfileId $profile.Id
    Write-Output "Deleted deployment profile: $($profile.DisplayName)"
  }
}

# Delete enrollment setup pages
$enrollmentPages = Get-MgBetaDeviceManagementDeviceEnrollmentConfiguration | where Assignment -ne $null
If(!$enrollmentpages){Write-output "No enrollment setup pages found."} Else{
foreach ($page in $enrollmentPages) {
    Remove-MgDeviceManagementEnrollmentConfigurationAssignment -EnrollmentConfigurationAssignmentId $page.Id
    Write-Output "Deleted enrollment setup page: $($page.DisplayName)"
  }
}

Write-Output - "Script execution completed."

