﻿#Variables - Remove Edge Settings
#$OMADMPath = 'HKLM:SOFTWARE\Microsoft\Provisioning\OMADM\Accounts\FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF'
#$EnrollmentPath = 'HKLM:SOFTWARE\Microsoft\Enrollments\FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF'
#$EdgePath = 'HKLM:SOFTWARE\Policies\Microsoft\Edge'


## Removal
#Remove-Item -Path $EnrollmentPath -ErrorAction SilentlyContinue
#Remove-Item -Path $OMADMPath -ErrorAction SilentlyContinue
#Remove-ItemProperty -Path $EdgePath -Name NewTabPageAllowedBackgroundTypes -ErrorAction SilentlyContinue 
#Remove-ItemProperty -Path $EdgePath -Name HomePageLocation -ErrorAction SilentlyContinue 
#Remove-ItemProperty -Path $EdgePath -Name NewTabPageLocation -ErrorAction SilentlyContinue
#Remove-ItemProperty -Path $EdgePath -Name NewTabPageContentEnabled -ErrorAction SilentlyContinue
#Remove-ItemProperty -Path $EdgePath -Name NewTabPageHideDefaultTopSites -ErrorAction SilentlyContinue
#Remove-ItemProperty -Path $EdgePath -Name ClearBrowsingDataOnExit -ErrorAction SilentlyContinue
#Remove-ItemProperty -Path $EdgePath -Name FavoritesBarEnabled -ErrorAction SilentlyContinue



# Check and install the Microsoft.Graph.Intune module if not present
#if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Intune)) {
#    Install-Module -Name Microsoft.Graph.Intune -Scope CurrentUser -Force -AllowClobber
#}

# Check and install the Microsoft.Graph.Beta module if not present
#if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Beta)) {
#    Install-Module -Name Microsoft.Graph.Beta -Scope CurrentUser -Force -AllowClobber
#}


# Import the necessary modules
#Import-Module Microsoft.Graph.Intune
#Import-Module Microsoft.Graph.Beta.DeviceManagement.Enrollment

# Connect to Azure AD interactively
#Connect-AzureAD | out-null


# Retrieve and delete all computer/device accounts in Azure AD
#$azureADDevices = Get-AzureADDevice
#foreach ($device in $azureADDevices) {
#    Remove-AzureADDevice -ObjectId $device.ObjectId
#    Write-Output "Deleted Azure AD device: $($device.DisplayName)"
#}

# Connect to Microsoft Graph (for Intune operations)
# Note: This will prompt you for authentication again, and you might need to provide consent for the Intune module to access your data.
#Connect-MgGraph -Scopes "DeviceManagementManagedDevices.ReadWrite.All","DeviceManagementServiceConfig.ReadWrite.All", "DeviceManagementConfiguration.ReadWrite.All" -ContextScope CurrentUser -NoWelcome | out-null

# Retrieve and delete all computers/devices in Intune
#$intuneDevices = Get-MgBetaDeviceManagementManagedDevice
#foreach ($device in $intuneDevices) {
#    Remove-MgDeviceManagementManagedDevice -ManagedDeviceId $device.Id
#    Write-Output "Deleted Intune device: $($device.DeviceName)"
#}

# Execute the command on SRV01 to remove the share and the folder 

 Invoke-Command -ComputerName SRV01 -ScriptBlock {
     # Check if the share exists
     $share = Get-SmbShare -Name MigStore -ErrorAction SilentlyContinue
     
     if ($null -ne $share) {
     # Remove the share
     Remove-SmbShare -Name MigStore -Force
     # Delete the folder
     $folderPath = "C:\MigStore"
     if (Test-Path $folderPath) {
     Remove-Item -Path $folderPath -Recurse -Force
     }
     
     Write-Output "Share 'MigStore' and folder 'C:\MigStore' have been deleted."
   } else {
     Write-Output "Share 'MigStore' does not exist."
   }
} 

 # Check for ADK installation
 
 $adk = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "*Assessment and Deployment Kit*" }
 
 # Uninstall ADK if found
 if ($null -ne $adk) {
     $adk.Uninstall()
     Write-Output "ADK has been uninstalled."
  } else {
      Write-Output "ADK is not installed."
  } 

# Function to delete specified files if they exist
function Delete-Files {
    param (
        [string]$computerName,
        [PSCredential]$credential
    )

    # Define the paths to the files
    $files = @(
        'My Notepad File.txt',
        'My Bitmap Image.bmp',
        'My Word Document.docx'
    )

    # Loop through each file and delete if it exists
    foreach ($file in $files) {
        $filePath = "\\$computerName\C$\Users\$env:USERNAME\Documents\$file"
        if (Test-Path $filePath) {
            Remove-Item -Path $filePath -Force
            Write-Output "Deleted $file on $computerName."
        } else {
            Write-Output "$file does not exist on $computerName."
        }
    }
}

# Define credentials for CL02
$securePassword = ConvertTo-SecureString "Passw0rd!" -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ("CL02\Admin", $securePassword)

# Delete files on the local computer
Delete-Files -computerName "CL01"

# Delete files on CL02
Delete-Files -computerName "CL02" -credential $cred

Echo "Script execution completed"

# Set the countdown duration
#$countdownDuration = 10

# Display the countdown
#for ($i = $countdownDuration; $i -gt 0; $i--) {
#    Clear-Host  # Clear the console
#    Write-Output "Script execution completed."
#    Write-Host "Restarting in $i seconds..."
#    Start-Sleep -Seconds 1
#}

# Restart the computer
#Restart-Computer