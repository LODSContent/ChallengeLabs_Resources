﻿# Check for ADK installation
 
 $adk = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "*Assessment and Deployment Kit*" }
 
 # Uninstall ADK if found
 if ($null -ne $adk) {
     $adk.Uninstall()
     Write-Output "ADK has been uninstalled."
  } else {
      Write-Output "ADK is not installed."
  } 

  Echo "Script execution completed"