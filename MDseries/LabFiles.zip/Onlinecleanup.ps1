﻿# Check and install the AzureAD.Standard.Preview module if not present
if (-not (Get-Module -ListAvailable -Name AzureAD.Standard.Preview)) {
    Install-Module -Name AzureAD.Standard.Preview -Scope CurrentUser -Force -AllowClobber
}

# Check and install the Microsoft.Graph.Intune module if not present
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Intune)) {
    Install-Module -Name Microsoft.Graph.Intune -Scope CurrentUser -Force -AllowClobber
}

# Import the necessary modules
Import-Module AzureAD.Standard.Preview
Import-Module Microsoft.Graph.Intune

# Connect to Azure AD interactively
Connect-AzureAD

# Retrieve and delete all computer/device accounts in Azure AD
$azureADDevices = Get-AzureADDevice
foreach ($device in $azureADDevices) {
    Remove-AzureADDevice -ObjectId $device.ObjectId
    Write-Output "Deleted Azure AD device: $($device.DisplayName)"
}

# Connect to Microsoft Graph (for Intune operations)
# Note: This will prompt you for authentication again, and you might need to provide consent for the Intune module to access your data.
Connect-MgGraph -Scopes "DeviceManagementManagedDevices.ReadWrite.All"

# Retrieve and delete all computers/devices in Intune
$intuneDevices = Get-MgDeviceManagementManagedDevice
foreach ($device in $intuneDevices) {
    Remove-MgDeviceManagementManagedDevice -ManagedDeviceId $device.Id
    Write-Output "Deleted Intune device: $($device.DeviceName)"
}

Write-Output "Script execution completed."
