﻿ # Connect to Azure AD interactively
Connect-AzureAD | Out-Null

# Connect to Microsoft Graph (for Intune operations)
Connect-MgGraph -Scopes "DeviceManagementManagedDevices.ReadWrite.All","DeviceManagementServiceConfig.ReadWrite.All", "DeviceManagementConfiguration.ReadWrite.All" -ContextScope CurrentUser -NoWelcome | out-null

# Retrieve all devices in AzureAD
$azureADDevices = Get-AzureADDevice  

# Retrieve all devices in Intune
$intuneDevices = Get-MgbetaDeviceManagementManagedDevice

# Check if there are any devices in Intune and if so, remove.
if ($intuneDevices.Count -eq 0) {
    Write-Output "No devices found in Intune."
} else {
    # Delete all devices in Intune
    foreach ($device in $intuneDevices) {
       Remove-MgbetaDeviceManagementManagedDevice -ManagedDeviceId $device.Id
       Write-Output "Deleted Intune device: $($device.DeviceName)"
    }
}  

# Check if there are any devices in Azure AD and if so, remove.
if ($azureADDevices.Count -eq 0) {
    Write-Output "No devices found in Azure AD."
} else {
    # Delete all devices in Azure AD
    foreach ($device in $azureADDevices) {
        Remove-AzureADDevice -ObjectId $device.ObjectId
        Write-Output "Deleted Azure AD device: $($device.DisplayName)"
    }
} 

Write-Output - "Script execution completed."

