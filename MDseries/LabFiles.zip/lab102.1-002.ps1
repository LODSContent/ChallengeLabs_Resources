﻿#Variables - Remove Edge Settings
$OMADMPath = 'HKLM:SOFTWARE\Microsoft\Provisioning\OMADM\Accounts\FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF'
$EnrollmentPath = 'HKLM:SOFTWARE\Microsoft\Enrollments\FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF'
$EdgePath = 'HKLM:SOFTWARE\Policies\Microsoft\Edge'


## Removal
Remove-Item -Path $EnrollmentPath -ErrorAction SilentlyContinue
Remove-Item -Path $OMADMPath -ErrorAction SilentlyContinue
Remove-ItemProperty -Path $EdgePath -Name NewTabPageAllowedBackgroundTypes -ErrorAction SilentlyContinue 
Remove-ItemProperty -Path $EdgePath -Name HomePageLocation -ErrorAction SilentlyContinue 
Remove-ItemProperty -Path $EdgePath -Name NewTabPageLocation -ErrorAction SilentlyContinue
Remove-ItemProperty -Path $EdgePath -Name NewTabPageContentEnabled -ErrorAction SilentlyContinue
Remove-ItemProperty -Path $EdgePath -Name NewTabPageHideDefaultTopSites -ErrorAction SilentlyContinue
Remove-ItemProperty -Path $EdgePath -Name ClearBrowsingDataOnExit -ErrorAction SilentlyContinue
Remove-ItemProperty -Path $EdgePath -Name FavoritesBarEnabled -ErrorAction SilentlyContinue



# Check and install the Microsoft.Graph.Intune module if not present
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Intune)) {
    Install-Module -Name Microsoft.Graph.Intune -Scope CurrentUser -Force -AllowClobber
}

# Check and install the Microsoft.Graph.Beta module if not present
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Beta)) {
    Install-Module -Name Microsoft.Graph.Beta -Scope CurrentUser -Force -AllowClobber
}


# Import the necessary modules
Import-Module Microsoft.Graph.Intune
Import-Module Microsoft.Graph.Beta.DeviceManagement.Enrollment

# Connect to Azure AD interactively
Connect-AzureAD | out-null


# Retrieve and delete all computer/device accounts in Azure AD
$azureADDevices = Get-AzureADDevice
foreach ($device in $azureADDevices) {
    Remove-AzureADDevice -ObjectId $device.ObjectId
    Write-Output "Deleted Azure AD device: $($device.DisplayName)"
}

# Connect to Microsoft Graph (for Intune operations)
# Note: This will prompt you for authentication again, and you might need to provide consent for the Intune module to access your data.
Connect-MgGraph -Scopes "DeviceManagementManagedDevices.ReadWrite.All","DeviceManagementServiceConfig.ReadWrite.All", "DeviceManagementConfiguration.ReadWrite.All" -ContextScope CurrentUser -NoWelcome | out-null

# Retrieve and delete all computers/devices in Intune
$intuneDevices = Get-MgBetaDeviceManagementManagedDevice
foreach ($device in $intuneDevices) {
    Remove-MgDeviceManagementManagedDevice -ManagedDeviceId $device.Id
    Write-Output "Deleted Intune device: $($device.DeviceName)"
}

# Set the countdown duration
$countdownDuration = 10

# Display the countdown
for ($i = $countdownDuration; $i -gt 0; $i--) {
    Clear-Host  # Clear the console
    Write-Output "Script execution completed."
    Write-Host "Restarting in $i seconds..."
    Start-Sleep -Seconds 1
}

# Restart the computer
Restart-Computer