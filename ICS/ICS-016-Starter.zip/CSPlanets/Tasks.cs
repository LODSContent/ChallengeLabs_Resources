using System;
using Microsoft.VisualBasic.FileIO;

namespace CSPlanets
{
    class MyTasks
    {
        //Add array declaration here

        public  void Requirement3()
        {
        }

        public  void Requirement4()
        {

        }

        public  void Requirement5()
        {

        }

        public  void Requirement6()
        {

        }
    }
}
