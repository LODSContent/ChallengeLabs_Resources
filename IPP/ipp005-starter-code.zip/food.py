

meal1 = (1, 2.50, 'code sandwich', 'green beans', 'french fries')
meal2 = (2, 2.50, 'cheeseburger', 'french fries')
meal3 = (3, 3.00, 'meatloaf', 'mashed potatoes', 'glazed apples', 'steamed carrots')
meal4 = (4, 2.50, 'spaghetti and meatballs', 'broccoli', 'pears')
meal5 = (5, 2.00, 'chicken nuggets', 'macaroni and cheese', 'grapes')


student1 = ('john doe', 54.25)
student2 = ('bob jackson', 235.98)
student3 = ('jill jackson', 93.54)
student4 = ('jackie johnson', 1.05)
student5 = ('darius terrell', 23.92)
student6 = ('maha connor', 5.65)
student7 = ('oskar ruiz', 32.12)
student8 = ('john doe', 54.25)


menu = None

balances = None

meals_ordered = None


def check_all_balances() -> None:
    pass


def find_meal(meal_id: int) -> tuple or None:
    pass


def checkout(student_id: int, meal_id: int) -> tuple or str:
    pass

