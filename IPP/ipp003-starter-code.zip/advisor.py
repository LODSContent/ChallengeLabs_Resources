
a_to_i = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
j_to_q = ['j', 'k', 'l', 'm', 'n', 'o', 'p', 'q']
r_to_z = ['r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


def determine_advisor(last_name: str) -> str:
    pass
