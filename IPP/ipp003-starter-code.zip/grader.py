
def determine_bonus_points(attendance: int, community_service_hours: int,
                           had_detention: bool) -> str:
    pass
