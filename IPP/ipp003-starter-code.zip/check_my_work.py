
import sys
import io
from lunchtime import determine_lunchtime
from advisor import determine_advisor
from grader import determine_bonus_points

task_number = 0

# read task number
try:
    task_number = sys.argv[1]
except:
    print('Incorrect usage!')
    print('Execute this command with an integer as the first argument which'
    ' specifies the requirement which validation is being requested for.')

def capture_stdout():
    # Memorize the default stdout stream
    old_stdout = sys.stdout 
    sys.stdout = buffer = io.StringIO()
    return old_stdout, buffer

def reassign_default_stdout(old_stdout, buffer):
    # Put the old stream back in place
    sys.stdout = old_stdout 
    # Return a str containing the entire contents of the buffer.
    whatWasPrinted = buffer.getvalue() 
    print(whatWasPrinted)
    return whatWasPrinted

if task_number == '1':
    first_expected_output = 'lunchtime is 11am for student #1234\n'
    second_expected_output = 'lunchtime is 12pm for student #1357\n'
    capture_variables = capture_stdout()
    determine_lunchtime(1234)
    first_actual_output = capture_variables[1].getvalue()
    reassign_default_stdout(capture_variables[0], capture_variables[1])
    capture_variables = capture_stdout()
    determine_lunchtime(1357)
    second_actual_output = capture_variables[1].getvalue()
    reassign_default_stdout(capture_variables[0], capture_variables[1])
    if first_actual_output == first_expected_output:
        print('You correctly assigned the lunchtime for students with even'
        ' numbered student IDs')
    else:
        print('You did NOT correctly assign the lunchtime for students with'
        ' even numbered student IDs')
    if second_actual_output == second_expected_output:
        print('You correctly assigned the lunchtime for students with odd'
        ' numbered student IDs')
    else:
        print('You did NOT correctly assign the lunchtime for students with'
        ' odd numbered student IDs')
    # write the failure statement here.
elif task_number == "2":
    first_expected_output = 'steve'
    second_expected_output = 'jessica'
    third_expected_output = 'marc'
    fourth_expected_output = ('123 does not begin with a valid lowercase,'
    ' alphabetic character')
    first_actual_output = determine_advisor('alvarez')
    second_actual_output = determine_advisor('owens')
    third_actual_output = determine_advisor('zuckerberg')
    fourth_actual_output = determine_advisor('123')
    if first_expected_output == first_actual_output:
        print('You successfully assigned the advisor for students with a'
        ' name beginning with a letter between "a" and "i"')
    else:
        print('You did NOT correctly assign the advisor for students with a'
        ' last name beginning with a letter between "a" and "i"')
    if second_expected_output == second_actual_output:
        print('You successfully assigned the advisor for students with a'
        ' name beginning with a letter between "j" and "q"')
    else:
        print('You did NOT correctly assign the advisor for students with a'
        ' last name beginning with a letter between "j" and "q"')
    if third_expected_output == third_actual_output:
        print('You successfully assigned the advisor for students with a'
        ' name beginning with a letter between "r" and "z"')
    else:
        print('You did NOT correctly assign the advisor for students with a'
        ' last name beginning with a letter between "r" and "z"')
    if fourth_expected_output == fourth_actual_output:
        print('You successfully returned the message for arguments'
        ' which do not begin with a lowercase alphabetic character')
    else:
        print('You did NOT correctly return the message for arguments'
        ' which do not begin with a lowercase alphabetic character')
elif task_number == "3":
    first_expected_output = 0
    second_expected_output = 5
    third_expected_output = 5
    fourth_expected_output = 10
    first_actual_output = determine_bonus_points(89, 4, True)
    second_actual_output = determine_bonus_points(90, 5, True) 
    third_actual_output = determine_bonus_points(89, 4, False) 
    fourth_actual_output = determine_bonus_points(98, 10, True)
    if first_expected_output == first_actual_output:
        print('You have successfully assigned bonus points when neither'
        ' criteria is met')
    else:
        print('You have NOT assigned the correct number of bonus points'
        ' when neither criteria is met')
    if second_expected_output == second_actual_output:
        print('You have successfully assigned bonus points when only the'
        ' condition including an AND statement is met')
    else:
        print('You have NOT correctly assigned bonus points when only the'
        ' condition including an AND statement is met')
    if third_expected_output == third_actual_output:
        print('You have successfully assigned bonus points when only the'
        ' condition including an OR statement is met')
    else:
        print('You have NOT correctly assigned bonus points when only the'
        ' condition including an OR statement is met')
    if fourth_expected_output == fourth_actual_output:
        print('You have successfully assigned bonus points when both'
        ' conditions are met')
    else:
        print('You have NOT correctly assigned bonus points when both'
        ' conditions are met')