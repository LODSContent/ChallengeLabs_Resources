
import sys
import io

task_number = 0

# read task number
try:
    task_number = sys.argv[1]
except:
    print('Incorrect usage!')
    print('Execute this command with an integer as the first argument which'
    ' specifies the requirement which validation is being requested for.')

def capture_stdout():
    # Memorize the default stdout stream
    old_stdout = sys.stdout 
    sys.stdout = buffer = io.StringIO()
    return old_stdout, buffer

def reassign_default_stdout(old_stdout, buffer):
    # Put the old stream back in place
    sys.stdout = old_stdout 
    # Return a str containing the entire contents of the buffer.
    whatWasPrinted = buffer.getvalue() 
    print(whatWasPrinted)
    return whatWasPrinted

if task_number == '1':
    from exam_mean import calculate_mean
    actual_mean = calculate_mean([1, 2, 3, 4, 5, 6, 7])
    expected_mean = 4
    if expected_mean == actual_mean:
        print('You have successfully written a function which calculates the mean of exam scores.')
    else:
        print('Your function doesn\'t produce the expected output. See the hints for guidance on how your solution differs.')
elif task_number == '2':
    from arrange_students import factorial, calculate_number_of_arrangements
    expected_factorial = 24
    actual_factorial = factorial(4)
    if expected_factorial == actual_factorial:
        print('You have succesfully written a function which calculates the factorial of an argument.')
    else:
        print('Your factorial() function doesn\'t match the expected output. See the hints for guidance on how your solution differs.')
    expected_number_of_arrangements_output = 'There are 24 unique ways to arrange the 4 students for the exam\n'
    captured_variables = capture_stdout()
    calculate_number_of_arrangements(4)
    actual_number_of_arrangements_output = reassign_default_stdout(captured_variables[0], captured_variables[1])
    if expected_number_of_arrangements_output == actual_number_of_arrangements_output:
        print('You have successfully written a function which calculates the number of seating arrangements for a classroom.')
    else:
        print('Your calculate_number_of_arrangements() function doesn\'t match the expected output. See the hints for guidance on how your solution differs.')
elif task_number == '3':
    from time_conv import print_time_remaining, timer
    captured_variables = capture_stdout()
    timer(1, 30)
    actual_timer_output = reassign_default_stdout(captured_variables[0], captured_variables[1])
    if actual_timer_output.find('Time remaining: 0 hour(s) 0 minute(s) 0 second(s)') == 278650:
        print('You have successfully written a function which simulates a timer')
    else:
        print('Your timer() function does\'t mtach the expected output. See the hints for guidance on how your solution differs.')

