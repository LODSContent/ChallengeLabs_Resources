from random import randint

def get_students_from_file()-> any:
    value = randint(1,10)
    if(value%2 == 0):
        raise FileNotFoundError
    else:
        raise PermissionError

def complete_registration(students):
    print('All the students in the following list have been successfully registered')
    print(students)