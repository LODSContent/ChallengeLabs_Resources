student_ids = ["1243","3455","3454","6342","6477","5846","7355","2647","4686","8453"]
classroom_even = []
classroom_odd = []

def sort_students():
    for student_id in student_ids:
        if(student_id) % 2 > 0:
            classroom_odd.append(student_id)
        else:
            classroom_even.append(student_id)
    print(f"classroom_even contains {classroom_even}")
    print(f"classroom_odd contains {classroom_odd}")
