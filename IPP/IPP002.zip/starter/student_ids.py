from students_support import random_number

def generate_student_id():
    pass

def verify_unique_student_id(student_id1, student_id2):
    pass
