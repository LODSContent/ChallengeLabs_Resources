import random


def random_number(seed):
    random.seed(int(seed))
    return str(random.randint(1,9))

