import os
import sys
import io
import subprocess
import traceback
import student_ids
import attendance


def capture_stdout():
    # Memorize the default stdout stream
    old_stdout = sys.stdout 
    sys.stdout = buffer = io.StringIO()
    return old_stdout, buffer


def reassign_default_stdout(old_stdout, buffer):
    # Put the old stream back in place
    sys.stdout = old_stdout 
    # Return a str containing the entire contents of the buffer.
    whatWasPrinted = buffer.getvalue() 
    print(whatWasPrinted)
    return whatWasPrinted


subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"],stdout = subprocess.DEVNULL)
subprocess.check_call([sys.executable, "-m", "pip", "install", "colorama"],stdout = subprocess.DEVNULL)

from colorama import Fore


def message_printer(passed, success_message, failure_message):
    if (passed):
        print(f"{Fore.GREEN}{success_message}{Fore.RESET}")
    else:
        print(f"{Fore.YELLOW}{failure_message}{Fore.RESET}")


def printed_list_finder(input_list)->str:
    value1 = input_list.find("[")
    value2 = input_list.find("]") + 1
    return input_list[value1:value2]

try:
    if (int(sys.argv[1]) == 1):
        student_id = student_ids.generate_student_id()
        message_printer(student_id=='3144526',"You have successfully created a student ID using a loop!","Your student ID doesn't match what was expected. Make sure you included a range from 1 to 8 like range(1, 8) and that your return statement is outside of the for loop.")
    if (int(sys.argv[1]) == 2):
        test1 = student_ids.verify_unique_student_id("3144526","3144526")
        test2 = student_ids.verify_unique_student_id("3144526","3145526")
        message_printer(test1 and not test2,"You have successfully used else and break to verify a unique student ID!","Your function doesn't match the expected output. Make sure that the else statement sets unique to True and that your return statement is outside of the else statement.")
    if (int(sys.argv[1]) == 3):
        expected_attendance_message = 'Jack is not in attendance\nJackson is not in attendance\n'
        captured_variables = capture_stdout()
        attendance.take_attendance(attendance.students)
        actual_attendance_message = reassign_default_stdout(captured_variables[0], captured_variables[1])
        message_printer(expected_attendance_message == actual_attendance_message, "You have successfully used a continue statement inside of a for loop to take attendance", "Your attendance function doesn't print the expected output. Make sure that the if statement evaluates the correct expression and that the print statement matches exactly what the instructions outline.")
except IndexError as e:
    print(Fore.RED)
    print(f"{e}\nPlease enter the task number you are attempting to check as a command line argument. \nExample: 'python3 check_my_work.py 1'")
    print(Fore.RESET)
except Exception as e:
    print(Fore.RED)
    traceback.print_exc()
    print(Fore.RESET)

