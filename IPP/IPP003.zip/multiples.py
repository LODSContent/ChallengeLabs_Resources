
from globals import numbers

def multiples():
    for x in numbers:
        # write your code here
