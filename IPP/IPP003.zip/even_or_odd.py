
from globals import numbers

def even_or_odd():
    for x in numbers:
        # write your code here
