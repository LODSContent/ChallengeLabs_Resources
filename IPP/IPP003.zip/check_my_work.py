
import sys
import io
from even_or_odd import even_or_odd
from multiples import multiples
from prime_fibonacci import prime_fibonacci
from globals import numbers, prime_numbers, fibonacci_numbers

task_number = 0

# read task number
try:
    task_number = sys.argv[1]
except:
    print('Incorrect usage!')
    print('Execute this command with an integer as the first argument which specifies the requirement which validation is being requested for.')

def capture_stdout():
    old_stdout = sys.stdout # Memorize the default stdout stream
    sys.stdout = buffer = io.StringIO()
    return old_stdout, buffer

def reassign_default_stdout(old_stdout, buffer):
    sys.stdout = old_stdout # Put the old stream back in place
    whatWasPrinted = buffer.getvalue() # Return a str containing the entire contents of the buffer.
    print(whatWasPrinted)
    return whatWasPrinted

if task_number == "1":
    # generate expected output
    expected_output = ""
    for x in numbers:
        _ = "odd"
        if x % 2 == 0:
            _ = "even"
        expected_output += f'{x} is {_}\n'
    
    capture_variables = capture_stdout()
    even_or_odd()
    actual_output = capture_variables[1].getvalue()
    reassign_default_stdout(capture_variables[0], capture_variables[1])
    if actual_output == expected_output:
        print("You completed the requirement successfully")
    else:
        print("Your output does not match the desired output.")
        print("It should look like:")
        print("1 is odd")
        print("2 is even")
        print("3 is odd")
        print("4 is even")
        print("...")
elif task_number == "2":
    # generate expected output
    expected_output = ""
    non_matches = 0
    for x in numbers:
        if x % 5 == 0:
            expected_output += f'{x} is a multiple of 5\n'
        # check each number for whether it's a multiple of 3 AND 7
        elif x % 3 == 0 and x % 7 == 0:
            expected_output += f'{x} is a multiple of both 3 and 7\n'
        else:
            non_matches += 1
    expected_output += f'{non_matches} of the numbers were not a multiple of 5 nor a multiple of both 3 and 7\n'

    capture_variables = capture_stdout()
    multiples()
    actual_output = capture_variables[1].getvalue()
    reassign_default_stdout(capture_variables[0], capture_variables[1])
    if actual_output == expected_output:
        print("You completed the requirement successfully")
    else:
        print("Your output does not match the desired output.")
        print("It should look like:")
        print("""
5 is a multiple of 5
10 is a multiple of 5
15 is a multiple of 5
20 is a multiple of 5
21 is a multiple of both 3 and 7
        """)
        print("...")
        print("76 of the numbers were not a multiple of 5 nor a multiple of both 3 and 7")
if task_number == "3":
    # generate expected output
    expected_output = ""
    for x in numbers:
        is_prime = x in prime_numbers
        is_fibonacci = x in fibonacci_numbers
        if is_prime and is_fibonacci:
            expected_output += f'{x} is both a prime number and a fibonacci number\n'
        elif is_prime or is_fibonacci:
            expected_output += f'{x} is either a prime number or a fibonacci number\n'

    capture_variables = capture_stdout()
    prime_fibonacci()
    actual_output = capture_variables[1].getvalue()
    reassign_default_stdout(capture_variables[0], capture_variables[1])
    if actual_output == expected_output:
        print("You completed the requirement successfully")
    else:
        print("Your output does not match the expected output.")
        print("It should look like:")
        print("""1 is either a prime number or a fibonacci number
2 is both a prime number and a fibonacci number
3 is either a prime number or a fibonacci number
5 is either a prime number or a fibonacci number
8 is either a prime number or a fibonacci number
11 is either a prime number or a fibonacci number
13 is both a prime number and a fibonacci number""")
        print("...")