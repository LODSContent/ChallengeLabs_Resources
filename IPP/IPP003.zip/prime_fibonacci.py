
from globals import numbers, prime_numbers, fibonacci_numbers

def prime_fibonacci():
    for x in numbers:
        # write your code here
        
