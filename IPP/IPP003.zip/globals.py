
# generate a list of 1 to 100
numbers = range(1, 101)

# generate prime numbers
prime_numbers = [2]

for x in range(2, 101):
    has_multiple = False
    nums = [2, 3, 5, 7]
    for i in nums:
        if x % i == 0:
            has_multiple = True
            break
    if has_multiple == False:
        prime_numbers.append(x)

# generate fibonacci numbers
fibonacci_numbers = [1, 2]
next_number = 0

while True:
    second_to_last_index = len(fibonacci_numbers) - 2
    last_index = len(fibonacci_numbers) - 1
    next_number = fibonacci_numbers[last_index] + fibonacci_numbers[second_to_last_index]
    if (next_number > 100):
        break
    fibonacci_numbers.append(next_number)
