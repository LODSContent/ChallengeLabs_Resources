
trimmable_name = '      John Doe  '
right_trimmable_name = 'John Doe    '
left_trimmable_name = '     John Doe'

