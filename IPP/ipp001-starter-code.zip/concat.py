
first_name = 'John'
last_name = "Doe"
gpa = 3.67

