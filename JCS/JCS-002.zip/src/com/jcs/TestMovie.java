package com.jcs;


public class TestMovie {
   public static void main(String[] args) {
      
   }

   public static void setTest(){

   }

   public static void comparableTest(){
      Movie movie = new Movie("Ocean Waves", 1993, "Tomomi Mochizuki", 88);

   }

   public static void comparatorTest(){
      Movie m = new Movie("Ponyo", 2008, "Hayao Miyazaki", 91);

   }
}
