package com.adj;

import java.io.IOException;

public class FileIOTest {

	public static void main(String[] args) throws IOException{
		String fileIn = "resources/http418-RFC.txt";
		String fileOut = "resources/http418-copy.txt";
		
		FileIO fileIO = new FileIO();
		String text = fileIO.readFileUsingScanner(fileIn);
		fileIO.writeFileUsingBufferedWriter(fileOut, text);
		
	}

}
