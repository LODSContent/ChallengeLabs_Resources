package com.adj;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileIO {

	public String readFileUsingScanner(String fileName) throws IOException{
		File file = new File(fileName);
		Scanner in  = new Scanner(file);
		StringBuilder builder = new StringBuilder();
		while(in.hasNextLine()) {
			builder.append(in.nextLine()+"\n");
			
		}
		in.close();
		return builder.toString();
	}
	
	
	public void writeFileUsingBufferedWriter(String fileName, String text) throws IOException{
		File file = new File(fileName);
		FileWriter out = new FileWriter(file);
		BufferedWriter bOut = new BufferedWriter(out);
		bOut.write(text);
		bOut.close();
		out.close();
	}
	
}
